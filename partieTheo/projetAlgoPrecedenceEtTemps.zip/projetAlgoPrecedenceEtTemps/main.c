#include <stdio.h>
#include <stdlib.h>
#include "lectureFichier.c"
#include "precedenceTemps.c"


int main(){
    int *tabPrecedence1=NULL, *tabPrecedence2=NULL, *tabExclusions1=NULL, *tabExclusions2=NULL;
    int *opSommets=NULL;
    float *opTemps=NULL;
    int tempsCycle = 0, nbLignesPrecedence = 0, nbLignesOperations=0, nbLignesExclusions=0;
    int *sommets = NULL;

    /// LECTURE FICHIER ///
    lecture(&tabPrecedence1, &tabPrecedence2, &tabExclusions1, &tabExclusions2, &nbLignesPrecedence, &nbLignesOperations, &nbLignesExclusions, &tempsCycle, &opSommets, &opTemps);


    ///DONNEES GRAPHE ///
    int ordre = nbLignesOperations;
    int taille = nbLignesPrecedence;
    int sommetMax = opSommets[nbLignesOperations-1];


    /// creer le graphe ///
    Graphe* graphe = creerGraphe(sommetMax+1);
    for (int i=0; i<taille; i++){ // Ajouter des arcs au graphe
        ajouterArc(graphe, tabPrecedence1[i], tabPrecedence2[i]);
    }

    Tache taches[sommetMax];

    int choix;



    // Utiliser switch-case pour exécuter l'étape correspondante
    while (choix !=4) {
        // Afficher le menu
        printf("\nMenu :\n");
        printf("1. Affichage graphe\n");
        printf("2. Precedence et temps de cycle V1\n");
        printf("3. Precedence et temps de cycle V2\n");
        printf("4. Quitter\n");
        printf("Entrez votre choix (1-4) : ");

        // Lire le choix de l'utilisateur
        scanf("%d", &choix);
        switch (choix){
            case 1:
                printf("Affichage du graphe.\n");
                affichageFichier(tempsCycle, ordre, taille, opSommets, graphe, sommetMax);
                break;
            case 2:
                printf("Precedence et temps de cycle V1.\n");
                PrecedenceEtTempsSuitee(taches, opSommets, nbLignesOperations, opTemps, sommetMax, tabPrecedence1, tabPrecedence2, taille, tempsCycle);
                break;
            case 3:
                printf("Precedence et temps de cycle V2.\n");
                PrecedenceEtTempsOpti(taches, opSommets, nbLignesOperations, opTemps, sommetMax, tabPrecedence1, tabPrecedence2, taille, tempsCycle);
                break;
            case 4:
                printf("Vous avez choisi l'Etape 4.\n");
                // Code pour l'Etape 4
                break;
            default:
                printf("Choix invalide. Veuillez entrer un nombre entre 1 et 4.\n");
                break;
        }
    }




    /// MEMOIRE ///
    //libérer la memoire
    free(tabPrecedence1);
    free(tabPrecedence2);
    free(opSommets);
    free(opTemps);
    free(sommets);
    free(graphe);

    return 0;
}
