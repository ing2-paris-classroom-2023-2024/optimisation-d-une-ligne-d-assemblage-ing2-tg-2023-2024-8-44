#include <stdio.h>
#include <stdlib.h>
#include "lectureFichier.c"
#include "precedenceTemps.c"


int main(){
    int *tabPrecedence1=NULL, *tabPrecedence2=NULL, *tabExclusions1=NULL, *tabExclusions2=NULL;
    int *opSommets=NULL;
    float *opTemps=NULL;
    int tempsCycle = 0, nbLignesPrecedence = 0, nbLignesOperations=0, nbLignesExclusions=0;
    int *sommets = NULL;

    /// LECTURE FICHIER ///
    lecture(&tabPrecedence1, &tabPrecedence2, &tabExclusions1, &tabExclusions2, &nbLignesPrecedence, &nbLignesOperations, &nbLignesExclusions, &tempsCycle, &opSommets, &opTemps);


    ///DONNEES GRAPHE ///
    int ordre = nbLignesOperations;
    int taille = nbLignesPrecedence;
    int sommetMax = opSommets[nbLignesOperations-1];


    /// creer le graphe ///
    Graphe* graphe = creerGraphe(sommetMax+1);
    for (int i=0; i<taille; i++){ // Ajouter des arcs au graphe
        ajouterArc(graphe, tabPrecedence1[i], tabPrecedence2[i]);
    }


    /// AFFICHAGE /// probleme avec le sommet 2
    affichageFichier(tempsCycle, ordre, taille, opSommets, graphe, sommetMax);



    /// TACHES ///
    Tache taches[sommetMax];
    //PrecedenceEtTempsSuitee(taches, opSommets, nbLignesOperations, opTemps, sommetMax, tabPrecedence1, tabPrecedence2, taille, tempsCycle);

    //V2:
    PrecedenceEtTempsOpti(taches, opSommets, nbLignesOperations, opTemps, sommetMax, tabPrecedence1, tabPrecedence2, taille, tempsCycle);

    /// MULTI CONTRAINTE ///
    //PrecedenceCycleContrainte(taches, opSommets, nbLignesOperations, opTemps, sommetMax, tabPrecedence1, tabPrecedence2, tabExclusions1, tabExclusions2, taille, tempsCycle);


    /// MEMOIRE ///
    //libérer la memoire
    free(tabPrecedence1);
    free(tabPrecedence2);
    free(opSommets);
    free(opTemps);
    free(sommets);
    free(graphe);

    return 0;
}
