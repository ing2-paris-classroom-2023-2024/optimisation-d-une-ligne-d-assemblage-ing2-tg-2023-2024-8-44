#include <stdio.h>
#include <stdlib.h>
#include "graphe.c"


void lecture(int **arc1, int **arc2, int **tabExclusion1, int **tabExclusion2, int *nbLignesPrecedence, int *nbLignesOperations, int *nbLignesExclusion, int *tempsCycle, int **opSommets, float **opTemps) {
    FILE *fichier = NULL;
    char ligne[10];
    int compteurPrecedence = 0;
    int compteurExclusion = 0;

    /// PRECEDENCES ///

    fichier = fopen("precedence.txt", "r"); // ouverture du fichier
    if (fichier == NULL) {
        printf("Erreur ouverture fichier precedence");
        exit(1);
    }

    while (fgets(ligne, sizeof(ligne), fichier) != NULL) { // tant qu'on a des lignes on les additionne
        (*nbLignesPrecedence)++;
    }

    // allocation dynamique
    *arc1 = (int*)malloc((*nbLignesPrecedence+1) * sizeof(int));
    *arc2 = (int*)malloc((*nbLignesPrecedence+1) * sizeof(int));

    // si problème avec les tableaux on sort du programme
    if (*arc1 == NULL || *arc2 == NULL) {
        printf("Erreur d'allocation de mémoire");
        fclose(fichier);
        free(*arc1);
        free(*arc2);
        exit(1);
    }

    // réinitialiser le pointeur du fichier au début
    fseek(fichier, 0, SEEK_SET);

    // vérifier si la ligne n'est pas vide et si elle contient bien 2 entiers
    while (fgets(ligne, sizeof(ligne), fichier) != NULL) {
        if (sscanf(ligne, "%d %d", &(*arc1)[compteurPrecedence], &(*arc2)[compteurPrecedence]) == 2) {
            compteurPrecedence++;
        }
    }
    fclose(fichier);


    /// TEMPS CYCLE ///

    fichier = fopen("temps_cycle.txt", "r"); // ouverture du fichier
    if (fichier == NULL) {
        printf("Erreur ouverture fichier temps_cycle");
        exit(1);
    }

    // Lire le temps de cycle depuis le fichier
    fscanf(fichier, "%d", tempsCycle); // Utilisez *tempsCycle pour accéder à la valeur pointée
    fclose(fichier);

    /// OPERATIONS ///
    compteurPrecedence = 0;  // réinitialiser le compteurPrecedence

    fichier = fopen("operations.txt", "r"); // ouverture du fichier
    if (fichier == NULL) {
        printf("Erreur ouverture fichier operations");
        exit(1);
    }

    while (fgets(ligne, sizeof(ligne), fichier) != NULL) { // tant qu'on a des lignes on les additionne
        (*nbLignesOperations)++;
    }

    // allocation dynamique
    *opSommets = (int*)malloc((*nbLignesOperations+1) * sizeof(int));
    *opTemps = (float*)malloc((*nbLignesOperations+1) * sizeof(float)); // Correction ici

    // si problème avec les tableaux on sort du programme
    if (*opTemps == NULL || *opSommets == NULL) {
        printf("Erreur d'allocation de mémoire");
        fclose(fichier);
        free(*opTemps);
        free(*opSommets);
        exit(1);
    }

    // réinitialiser le pointeur du fichier au début
    fseek(fichier, 0, SEEK_SET);

    // vérifier si la ligne n'est pas vide et si elle contient bien 2 entiers
    while (fgets(ligne, sizeof(ligne), fichier) != NULL) {
        if (sscanf(ligne, "%d %f", &(*opSommets)[compteurPrecedence], &(*opTemps)[compteurPrecedence]) == 2) { // Correction ici
            compteurPrecedence++;
        }
    }
    fclose(fichier);



    /// EXCLUSIONS ///

    fichier = fopen("exclusions.txt", "r"); // ouverture du fichier
    if (fichier == NULL) {
        printf("Erreur ouverture fichier");
        exit(1);
    }

    while (fgets(ligne, sizeof(ligne), fichier) != NULL) { // tant qu'on a des lignes on les additionne
        (*nbLignesExclusion)++;
    }

    // allocation dynamique
    *tabExclusion1 = (int*)malloc((*nbLignesExclusion+1) * sizeof(int));
    *tabExclusion2 = (int*)malloc((*nbLignesExclusion+1) * sizeof(int));

    // si problème avec les tableaux on sort du programme
    if (*tabExclusion1== NULL || *tabExclusion2 == NULL) {
        printf("Erreur d'allocation de mémoire ici "); // probleme ici
        fclose(fichier);
        free(*tabExclusion1);
        free(*tabExclusion2);
        exit(1);
    }

    // réinitialiser le pointeur du fichier au début
    fseek(fichier, 0, SEEK_SET);

    // vérifier si la ligne n'est pas vide et si elle contient bien 2 entiers
    while (fgets(ligne, sizeof(ligne), fichier) != NULL) {
        if (sscanf(ligne, "%d %d", &(*tabExclusion1)[compteurExclusion], &(*tabExclusion2)[compteurExclusion]) == 2){
            compteurExclusion++;
        }
    }
    fclose(fichier);
}

void affichageFichier(int tempsCycle, int ordre, int taille, int *opSommets, Graphe* graphe, int sommetMax){

    printf("\nInfos du graphe:\n");
    printf("Temps de cycle: %d\n", tempsCycle);
    printf("Ordre: %d\n", ordre-1);
    printf("Taille: %d\n", taille);

    // Afficher le graphe
    printf("\n\n/// GRAPHE ORIENTE ///\n\n");
    afficherGraphe(graphe);
}

